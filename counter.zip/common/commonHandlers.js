const barkeep = require('../helpers/barkeep')

module.exports = {
    LaunchHandler: {
        canHandle(handlerInput) {
            request = handlerInput.requestEnvelope.request;
            return request.type === 'LaunchRequest';
        },
        async handle(handlerInput) {
            specials = await barkeep.getRandomDrink();
            const speech = `Welcome! How may I help you today?` +
                ` You can ask for a specific cocktail recipe, by saying the drink's name.` +
                ` Or say surprise me to get a the barkeep's choice.` + 
                ` Let me know and I will do the best I can.`;
            return handlerInput.responseBuilder
                .speak(speech)
                .reprompt(speech)
                .withShouldEndSession(false)
                .getResponse();
        }
    },
    ExitHandler: {
        canHandle(handlerInput) {
            request = handlerInput.requestEnvelope.request;
            return request.type === 'IntentRequest'
                && (request.intent.name == 'AMAZON.CancelIntent'
                    || request.intent.name == 'AMAZON.StopIntent');
        },
        handle(handlerInput) {
            const speech = `Good bye!`
            return handlerInput.responseBuilder
                .speak(speech)
                .reprompt(speech)
                .getResponse();
        }
    },
    HelpHandler: {
        canHandle(handlerInput) {
            request = handlerInput.requestEnvelope.request;
            return request.type === 'IntentRequest'
                && (request.intent.name == 'AMAZON.HelpIntent'
                    || request.intent.name == 'AMAZON.FallbackIntent');
        },
        handle(handlerInput) {
            const speech = `Welcome! How may I help you today?` +
                ` You can ask for a specific cocktail recipe, by saying the drink's name.` +
                ` Or say surprise me to get a the barkeep's choice. `;
            return handlerInput.responseBuilder
                .speak(speech)
                .reprompt(speech)
                .getResponse();
        }
    },
    SessionEndedRequestHandler: {
        canHandle(handlerInput) {
            request = handlerInput.requestEnvelope.request;
            return request.type === 'IntentRequest'
                && request.intent.name == 'AMAZON.HelpIntent';
        },
        handle(handlerInput) {
            return handlerInput.responseBuilder
                .speak('Welcome to the bar, how may I help you?')
                .reprompt('Welcome to the bar, how may I help you?')
                .getResponse();
        }
    }
}