const http = require('axios');

const baseUrl = "https://barkeep-core.herokuapp.com";
module.exports = {
    getRandomDrink: async function (liquor) {
        const url = baseUrl + '/bar/menu/surpriseme';
        return http.get(url,
            {'headers': 
                { 'content-type': 'text/plain' }
            }
        );
    },
    getBarMenu: async function () {
        const url = baseUrl + '/bar/menu';
        return http.get(url,
            {'headers': 
                { 'content-type': 'application/json' }
            }
        );
    },
    getBarMenuAvailable: async function () {
        const url = baseUrl + '/bar/menu/available';
        return http.get(url,
            {'headers': 
                { 'content-type': 'application/json' }
            }
        );
    },
    getRecipe: async function (drink) {
        const url = baseUrl + `/bar/recipe/${drink}`;
        return http.get(url,
            {'headers': 
                { 'content-type': 'application/json' }
            }
        );
    }
}